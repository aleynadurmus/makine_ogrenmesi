import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
"""
destek vektor makineleri
regresyondan önce sınıflandırma olarak kullanıldı
dogrusal olarak birbirinden ayrılan sınıfları dogrularla böler
amaç max marjinali , en geniş dogruyu cizmeye yarar
max marjin alınır
max aralıga sahiptir
regresyona geçilince
birden fazla dogru cizilip max aralıgı alır max noktayı içine alan dogru tercih edilir
eğrilerde cizilebilir,max pointi alanı tercih ederiz
marjin aralıgı ne kadar kücükse daha değerli regresyon olur
dogrusal olmayan svr ler de vardır
burada fonksiyonların gösterimleri hesaplamalrı değişir
dogrusal,polinomal,gaussian,ussel hali vardır
scaller kullanmak zorundayız standartlaştırarak kullanmak zorundayız

"""
"""
destek vektor makine sınıflandırması
2 sınıfı birbirinden ayıran en iyi sınıflandırmayı e iyi dogruyu bulmaktır amac
marjini maximum eden aralıgı alır
en geniş marjin aralıgı alır
destek noktalarıımz oluyor sınır bu aralıktadır
sınıflandrımada bu aralıga hiç nokta dusmemesini sağlamak
k-nn her noktayı ögreniyordu burada ise sınırın yazılabileceğini gösteriyor
sınır ayrımlarının fonksiyonu yazılabileceğini bize gösteriyor.
paralelleştirmede kullanılmıyor
"""

"""##SVR UYGULAMASI
veriler = pd.read_csv('maaslar.csv')
print(veriler)
#data frame dilimleme , yani sutunları aldık ,dilimi aldık
x=veriler.iloc[:,1:2]
y=veriler.iloc[:,2:] #sutunları alırız
#numpy arraye cevirmiş oluyoruz
X=x.values
Y=y.values



sc=StandardScaler() 
X_train=sc.fit_transform(X)

sc1=StandardScaler() 
Y_train=sc1.fit_transform(Y)


support=SVR(kernel='rbf') #bunu tercih ettik
support.fit(X_train,Y_train)
plt.scatter(X_train,Y_train)
plt.plot(X_train,support.predict(X_train))


print(support.predict([[11]]))
"""

##SVC uyuglaması

veriler = pd.read_csv('veriler.csv')


x=veriler.iloc[:,1:4].values
y=veriler.iloc[:,4:].values



x_train, x_test,y_train,y_test = train_test_split(x,y,test_size=0.33, random_state=0)


support=SVC(kernel='rbf') #bunu tercih ettik
support.fit(x_train,y_train) #rbf ayrım bulmaya calısacak

y_pred=support.predict(x_test)
cm=confusion_matrix(y_test,y_pred)
print(y_pred)
print(cm)





"""
kernel trick
marjinler içerisinde nokta varsa , nokta kabul etmiyorsa hard- marjin
eğer içerisinden hata olarak noktaları kabul ediyorsa buna soft- marijn deniyor
doğrusal olmayan durumlarda çekirdek (kernel) hileleri kullanılır,boyut arttırılmaya gidilir
iç içe sınıflarda genellikle kullanılır,3.bir boyut elde etmeye calısılır.
svm kullanarak 3.boyuta geçip burada dairesel içiçe girmiş sınıfları ayırırız
non linear sınıflar yari iç içe daire gibi gözüken şeye denir.
kernel fonk kullanılarak dogu sigma değerine sahip olanı dağıtarak elde etmek
kesebileceğimiz bir nokta elde ederiz.
dogrusal olmayan durumlarda tercih edilir.


çoklu kernel kullanımı
cok daha değişik dalgalı verileri olduğu durumda şekli değişik durumlarda birde fazla kernel kullanılır
birden fazla kernel noktası belirleyip birden fazla noktadan cekip elde ederiz 
gamma ve C değişimleri ile sonucların arasında farklılıklar olusur

"""
