import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
#veriyi yükleme
veriler=pd.read_csv('titanic.csv')
print(veriler)

#veri içindeki sutünü kaydetme
yas=veriler[['Survived']]
print(yas)



#kayıp-eksik veriler
#sayısal yöntemler için kullanılacak yöntemeler;
#ortalamayı alarak olmayan veriler yerine yazarız.
#♦mean ortalama alarak nan ları dolduracağımızı belirtir
#fit işlemi egitmede kullanılır ogrenecek değer
#fit ile öğretip trasnform ile öğrendiğini uygulamasını sağlarız
imputer=SimpleImputer(missing_values=np.nan,strategy='mean')
yeni_yas=yas.iloc[:,].values
print(yeni_yas)
imputer=imputer.fit(yeni_yas[:,]) #yenni yası imputer ile eğitiriz
yeni_yas[:,]=imputer.transform(yeni_yas[:,])
print(yeni_yas)
#replace ile eski veri ile yeni veri değiştirilebilir

#yapılan işlemleri birleştirmek
sonuc=pd.DataFrame(data=yeni_yas, index=range(891),columns=['Survived'])
print(sonuc)
sonuc2=pd.DataFrame(data=veriler, index=range(891),columns=['Sex','Age'])

s=pd.concat([sonuc,sonuc2])
#contact ile birleştirilir sutunlar
print(s)
