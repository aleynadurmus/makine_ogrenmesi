import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.cluster import KMeans
"""
kümeleme
gözetimsiz eğitim oluyor.
elimizde kaç sınıf ve örnek oldugunu bilmiyoruz ve kendimiz sınıflandırmaya calısıyoruz
müşteri segmentasyonu,pazar segmentasyonu,sağlık ve görüntü işleme de kullanılı
müşteriye dogru urunu satabilmek için tanımamız gerekiyor fakat önceden bununla ilgili bilgimiz olmuyo
collaboration filtering:diğer müsterileriyle benzeyen davranısları sergileyen gruplar bakılır. 
geçmiş verilere bakarak birşeyler çıkarmak ve musteri segmentasyonu ile ayrılıyor
aynı gruptaki kişiilere benzer şeyleri satmak.
tehdit ve sahtekarlık yapanları sınıflandrıırıp bunları biliriz öncesinden sınıflayıp o gruba koyarız
bölütleme ise;grupların dışında kalan,bölete girmeyen örnekler olabilir
segmentlere ayırarak sınıflandrıma yapıp bu şekilde tahminler yaptrırız.
verinin alt kümesi üzerinde yapılan bütün işlemler


"""
"""


K-means (k-ortalama)
kaç küme olacapı kullanıcıdan parametre ile seçilir
rastegele olarak k merkez noktası seçiklir,her veri örmeği en yakın merkez noktasına göre kümeye atılır
her küme için yeni merkez noktaları hesaplanarak merkez noktaları kayıdırlır
merkez noktaları kaydırılarak gelen yeni verilere göre sınıflandırma yapılır
değişik bölütleme algoritmaları vardır.


bu algoritmanın sıkıntısı;
başlangıc noktası tuzagı:data pointler dağılınıca herkes en yakınına gruplanır.
bazen rastgele istediğiömiz grup merkezleri istediğimiz gibi olmayabilir.
istenilen sınıf gruplarına atanmamış olabilir
k-means rastegele olarak başladığı için bu bir sıkıntıdır.istediğimiz gibi sınıflandırmaya gruplandırmaya bilir
bu gibi problemler için K-means++ ile daha iyileştirilmiştir.
k-means ++ ile rastgele secilen noktalardan en yakınına her noktadan uzaklıgı hesaplar
ve yeni noktaları mesafenin karesini olarasolık alarak hesaplar.D(X)^2

başka sıkıntısı;k biz önceden kaç sınıf istediğimizi vermemiz gerekiyor.
k değerinin kaç olacagını da belirlemek önemlidir. gözetimsiz ögrenme oldugu için ön bilgimiz yok
haliyle kaç sınıf olacagını da kesin değilbu yuzden bölütlemeyi dogru ayarlamak gerekir.
optimum noktayu dogru belirlememiz gerekiyor


WCSS
kendimiz bir sınıf aralıgını sisteme veririz .kendisi dener ve sonra sonucları gösterir.
her class için bir hesap yapar

"""

veriler = pd.read_csv('musteriler.csv')


x=veriler.iloc[:,3:].values 



sc=StandardScaler()


kmeans=KMeans(n_clusters=3,init='k-means++')
kmeans.fit(x)


print(kmeans.cluster_centers_) #orta noktayı verir
sonuclar=[]
for i in range(1,10):
    kmeans=KMeans(n_clusters=i,init='k-means++',random_state=123)
    
    kmeans.fit(x)
    sonuclar.append(kmeans.inertia_)
    
plt.plot(range(1,10),sonuclar)















