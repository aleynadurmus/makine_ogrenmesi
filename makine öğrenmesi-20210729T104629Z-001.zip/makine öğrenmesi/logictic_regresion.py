import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
"""
1/(1+e^-t)
sayısal değerler uzerinde sınıflandırma yapıyor,
birden fazla parametreyi alarak sınıflandırma yapıyor
sınıflandrıma algoritmalarından biridir
"""


veriler = pd.read_csv('veriler.csv')


x=veriler.iloc[:,1:4].values
y=veriler.iloc[:,4:].values


x_train, x_test,y_train,y_test = train_test_split(x,y,test_size=0.33, random_state=0)
sc=StandardScaler()
X_train=sc.fit_transform(x_train)
X_test=sc.fit_transform(x_test)

log=LogisticRegression(random_state=0)

log.fit(X_train,y_train)
y_pred=log.predict(X_test)
print(y_pred)





