
"""
lineer dogrusal boyut indirme
PCA benzeri  bir indirgeme yapar
en büyük farklılık ilk adımda;
PCA da label atlayarak başlar gözemtisizdir,sınıf farkı yo saar
LDA da ise gözetimli olarak sınıflandırma ön planlıdır
"""

#1. kutuphaneler
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
# veri kümesi
veriler = pd.read_csv('Wine.csv')
X = veriler.iloc[:, 0:13].values #bagımsız değişken
y = veriler.iloc[:, 13].values#bagımlı değişkenleri alırız
#kolonları daha az sayıya indirgemeyi sağlarız
# eğitim ve test kümelerinin bölünmesi

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

# Ölçekleme

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)



#lda
lda=LDA(n_components=2)
x_train_lda=lda.fit_transform(X_train,y_train)
x_test_lda=lda.transform(X_test)
 #lda dönüşüm sonrasında
 
kclas=LogisticRegression(random_state=0)
kclas.fit(x_train_lda,y_train)
y_pred_lda=kclas.predict(x_test_lda)

