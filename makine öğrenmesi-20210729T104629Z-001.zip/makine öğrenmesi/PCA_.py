
"""
boyut indirgeme yöntemidir
eigen value(öz değer) , eigen vector(öz yöney)
rastgele bir matris alalım bu matrisi tek bouyutlu bir matris ile çarparsak;
çarpım şayet çarpanın herhangi bir skalar katını veriyorsa bunlara öz değer deniyor
indirgenmek istenen boyut k olsun;
veri standartlaştırılır
kovaryans veya corelasyom namtrisinden öz değerleri elde ederiz v
öz değerler büyükten kucuge sıralanır ve k tanesini alırız.
boyut indirgeme PCA yöntemiyle kullanılır yanygındır

"""


#1. kutuphaneler
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
# veri kümesi
veriler = pd.read_csv('Wine.csv')
X = veriler.iloc[:, 0:13].values #bagımsız değişken
y = veriler.iloc[:, 13].values#bagımlı değişkenleri alırız
#kolonları daha az sayıya indirgemeyi sağlarız
# eğitim ve test kümelerinin bölünmesi

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

# Ölçekleme

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

# PCA

pca = PCA(n_components = 2) #indrigemesi intenen boyut=2

X_train2 = pca.fit_transform(X_train)
X_test2 = pca.transform(X_test)

#pca dönüşümünden önce gelen LR

classifier = LogisticRegression(random_state=0)
classifier.fit(X_train,y_train)

#pca dönüşümünden sonra gelen LR , 
classifier2 = LogisticRegression(random_state=0)
classifier2.fit(X_train2,y_train)

#tahminler
y_pred = classifier.predict(X_test)

y_pred2 = classifier2.predict(X_test2)


#actual / PCA olmadan çıkan sonuç
print('gercek / PCAsiz')
cm = confusion_matrix(y_test,y_pred)
print(cm)

#actual / PCA sonrası çıkan sonuç
print("gercek / pca ile")
cm2 = confusion_matrix(y_test,y_pred2)
print(cm2)

#PCA sonrası / PCA öncesi
print('pcasiz ve pcali')
cm3 = confusion_matrix(y_pred,y_pred2)
print(cm3)














