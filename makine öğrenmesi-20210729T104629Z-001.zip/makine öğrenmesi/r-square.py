import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score

"""
r-square
hata kareleri toplamı 
(gercekte olması gereken-tahmini)^2
eksiye düşmemek için karesini alıyoruz
en son hatalarını bulduktan sonra toplarız
1'e ne kadar yakınsa o kadar doğru sonuc elde ederiz

"""

"""

düzeltilmiş r-square
sistemin iyi calısmasını sağlayacak
olumlu değer ekleiyorsak r square artar 
ama eklediğimiz hiçbir değer r square azaltmıyor
olumsuz ektilerin herhangi bir arttırma yapmıyor
böyle olunca olumsuz etkenleri tespit edemiyoruz
sistemi değerlendirmek için olumlu yönleri vardır


"""



veriler = pd.read_csv('maaslar.csv')
print(veriler)
#data frame dilimleme , yani sutunları aldık ,dilimi aldık
x=veriler.iloc[:,1:2]
y=veriler.iloc[:,2:] #sutunları alırız
#numpy arraye cevirmiş oluyoruz
X=x.values
Y=y.values

#bütün değerleri bölerek öğrenir
#kaç tane karar agac çizeceğini gösreririz (estiminator) 10 dedik
r_dt=RandomForestRegressor(n_estimators=20,random_state=0)
r_dt.fit(X,Y)


#r square ile dogrulugunu bize göstermis oluyor

print(r2_score(Y,r_dt.predict(X)))
# r_score düşükse ; iyileştirmeye gidilir
#bu iyileştirme polinom derecesini arttırıma,hangi verilerin dahil edileceğie karar verme