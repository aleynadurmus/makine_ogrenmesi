import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

#kollektif öğrenme:aynı anda birden fazla yöntem kullanma
#random forest birden fazla karar ağacları kullanılması ve hepsinin yanı anda kullanılması
#veri kümesini alt kümelere bölerek parçalarbirden fazla karar agacı olusturu
#amac veri kümesini irden fazla parçaya bölüp karar ağaçları olusturmak sonrasında sonucları birleştirmek
#veriseti fazla oldugunda karar agacları pasif kalıyor burada ise random forestte daha iyidir
#veri fazla olunca karar agacları ezberliyor burada ise daha iyi sonuc alııyor

"""
veriler = pd.read_csv('maaslar.csv')
print(veriler)
#data frame dilimleme , yani sutunları aldık ,dilimi aldık
x=veriler.iloc[:,1:2]
y=veriler.iloc[:,2:] #sutunları alırız
#numpy arraye cevirmiş oluyoruz
X=x.values
Y=y.values

#bütün değerleri bölerek öğrenir
#kaç tane karar agac çizeceğini gösreririz (estiminator) 10 dedik
r_dt=RandomForestRegressor(n_estimators=20,random_state=0)
r_dt.fit(X,Y)

plt.scatter(X,Y.ravel())
plt.plot(X,r_dt.predict(X))


print(r_dt.predict([[9]]))


"""



#rassal orman sınıflandırma
#direkt dogrudan oyların uzerinden coğunlugun dediği oluyor.




veriler = pd.read_csv('veriler.csv')

x=veriler.iloc[:,1:4].values
y=veriler.iloc[:,4:].values

x_train, x_test,y_train,y_test = train_test_split(x,y,test_size=0.33, random_state=0)


sc=StandardScaler()
xx_train=sc.fit_transform(x_train)
xx_test=sc.fit_transform(x_test)


r_dt=RandomForestClassifier()

r_dt.fit(xx_train,y_train) 

y_pred=r_dt.predict(xx_test)
y_proba=r_dt.predict_proba(xx_test) #bize olasılıkları veriri.
cm=confusion_matrix(y_test,y_pred)
fpr,tpr,thold=metrics.roc_curve(y_test,y_proba[:,0],pos_label='e')
print(y_pred)
print(y_proba[:,0])
print(cm)
print(fpr)
print(tpr)


