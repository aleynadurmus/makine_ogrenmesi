import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB

"""
her bölgenin özelliklerini alıyor
özelliklere göre sınıflandırma yapıyor.sınıflandrıma için daha uygun bir yöntemdtir
overfitting olma ihtimali vardir,ezberlmeeye düşüyor
her örneğe göre bölge cıkarıyor


ID3 algoritması
(enformasyon kazanımı)
criterion:entropi kullanılıyor 
criterian:
entropi:
"""
veriler = pd.read_csv('veriler.csv')



x=veriler.iloc[:,1:4].values
y=veriler.iloc[:,4:].values

x_train, x_test,y_train,y_test = train_test_split(x,y,test_size=0.33, random_state=0)


sc=StandardScaler()
xx_train=sc.fit_transform(x_train)
xx_test=sc.fit_transform(x_test)


tree=DecisionTreeClassifier(criterion='entropy')
tree.fit(xx_train,y_train) 

y_pred=tree.predict(xx_test)
cm=confusion_matrix(y_test,y_pred)
print(y_pred)
print(cm)



