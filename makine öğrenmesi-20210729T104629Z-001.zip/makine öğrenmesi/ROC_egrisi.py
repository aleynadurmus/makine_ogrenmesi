import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix

"""
ROC
sınıflandırma algoritmalarını karşılaştırmada bizim işimize yarar.
ROC CONvex hull ile sınıflandırma ile hangi algoritöaın daha iyi oldugunu elde tutarız
veri zarflama anaiziyle uzaya yerleştirilen noktaların birleştirilmesi ile bölgenin içinde  kalanı söyler
prevalence gerçekteki yes dagılımı oranı
algrotima seçiminde accurucay oranlarına bakmak gerek


AUC

ne kadar fazlaysa bizim için sınıfladrıma basarım oranı o kaar iyi oluyor
"""