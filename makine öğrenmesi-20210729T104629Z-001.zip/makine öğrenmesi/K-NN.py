import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier

"""
uzaydaki sınıflandırmaya göre yeni bir örneğin sınıflandırılması e yakın komsu sınıfa göre sınıflandırılır
k kaç komsu oldugunu söyler 
3 komsu olsun en yakın olana göre sınıflandırılır
mesafe ölçüm algoritmaları değişiyor, 
lazy learning rastegele olarak geleni en yakına atıyor,bölge cıkarmıyor
bölgeleri olusturmaya regian bölge cıkartıyor (nearest)
metric olarak minkowski kullanlır, destance metrik farklı verilebilir euclidean var manhattan distance alınabilr,(santranc mesafesi)

"""


veriler = pd.read_csv('veriler.csv')


x=veriler.iloc[:,1:4].values
y=veriler.iloc[:,4:].values


x_train, x_test,y_train,y_test = train_test_split(x,y,test_size=0.33, random_state=0)



knn=KNeighborsClassifier(n_neighbors=5,metric='minkowski')
knn.fit(x_train,y_train)
y_pred=knn.predict(x_test)
cm=confusion_matrix(y_test,y_pred)
print(cm)


#[5 2] 5 tanede 2 tane başarı var



