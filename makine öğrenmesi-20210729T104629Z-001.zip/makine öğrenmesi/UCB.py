import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
import scipy.cluster.hierarchy as sch
import random
import math

"""
üst güven sınırı (UCB)
aralarında rahat hareket edeceğiz istatiksel aralık oluyor
dağılımları en avantajlı hale nsıl ceviririz?
kullnaıcı her seferinden bir eylem yapar
bu eylem karsısında bir skor döner 1 0 gibi
bunu bize döndürerek hangisnin daha cok tercih edildiğini buluruz
reklam verileri tıklamış ya da tıklamamıs durumudur en fazla tıklananna yatırım yapmka
bazı tecrübeleri bir sonraki seçime yansıtır
her turda her reklam alternatifi  N:tıklama sayısı

"""
"""
random selection
random olarak değerleri atar.

"""

veriler = pd.read_csv('Ads_CTR_Optimisation.csv')

"""
random 
N=10000
d=10
toplam=0
secilenler=[]
for n in range(0,N): #N=kaç tur
    ad=random.randrange(d)
    secilenler.append(ad)
    odul=veriler.values[n,ad] #verilerdeki n, satır=1 ise odul 1  
    #o anki tıklanan reklmaların ödülü
    toplam=toplam+odul
    
plt.hist(secilenler)
plt.show()
    """
    

#UCB
N = 10000 # 10.000 tıklama
d = 10  # toplam 10 ilan var
#Ri(n)
oduller = [0] * d #ilk basta butun ilanların odulu 0
#Ni(n)
tiklamalar = [0] * d #o ana kadarki tıklamalar
toplam = 0 # toplam odul
secilenler = []
for n in range(1,N):
    ad = 0 #seçilen ilan
    max_ucb = 0
    for i in range(0,d):
        if(tiklamalar[i] > 0):
            ortalama = oduller[i] / tiklamalar[i]
            delta = math.sqrt(3/2* math.log(n)/tiklamalar[i])
            ucb = ortalama + delta
        else:
            ucb = N*10
        if max_ucb < ucb: #max'tan büyük bir ucb çıktı
            max_ucb = ucb
            ad = i          
    secilenler.append(ad)
    tiklamalar[ad] = tiklamalar[ad]+ 1
    odul = veriler.values[n,ad] # verilerdeki n. satır = 1 ise odul 1
    oduller[ad] = oduller[ad]+ odul
    toplam = toplam + odul
print('Toplam Odul:')   
print(toplam)

plt.hist(secilenler)
plt.show()

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
