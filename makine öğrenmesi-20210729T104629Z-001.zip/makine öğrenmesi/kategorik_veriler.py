import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
#veriyi yükleme
veriler=pd.read_csv('titanic.csv')
print(veriler)

#veri içindeki sutünü kaydetme

cins=veriler[['Sex']]
print(cins)
#iloc ile veriler alınır
cinsiyet=cins.iloc[:,0].values
print(cinsiyet)

#cinsiyet kısmında olan erkek ve kadını 1-0 a dönüştürür
#kategorik veriler yazı , metnin sayıya cevrilmesidir.
#sayısala dönüştürülür onehotencoder ile
le=preprocessing.LabelEncoder()
#tek satırda fit edip transformunu alır
cinsiyet[:,0]=le.fit_transform(cins.iloc[:,0])
print(cinsiyet)
#0-1 olarak etiketler:onehot
ohe=preprocessing.OneHotEncoder()

cinsiyet=ohe.fit_transform(cinsiyet).toarray()
print(cinsiyet)