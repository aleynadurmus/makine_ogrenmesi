import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
veriler=pd.read_csv('titanic.csv')
print(veriler)

#olusturulan dönüşümler ile dataframeler colums halinde yazılır
sonuc=pd.DataFrame(data=veriler, index=range(891),columns=['Survived'])

sonuc2=pd.DataFrame(data=veriler, index=range(891),columns=['Age'])
sonuc3=pd.DataFrame(data=veriler, index=range(891),columns=['Sex'])

#contact ile birleştirirlir.

#rastgele olarak belirli satırları alıp test train olarak 4 e böler
#rastegele olarak test ve train olarak ayırırız
x_train,x_test,y_train,y_test=train_test_split(sonuc2,sonuc3,test_size=0.33,random_state=0)

#öznitelik ölçekleme
#farklı verileri bir yerde toplayarak neyin ne kadar etkili olduğu bulunr
#standartlastırılarak normalleştirerek benzer hale getirdik
sc=StandardScaler()
X_train=sc.fit_transform(x_train)
X_test=sc.fit_transform(x_test)

#veri önişleme tablosu












