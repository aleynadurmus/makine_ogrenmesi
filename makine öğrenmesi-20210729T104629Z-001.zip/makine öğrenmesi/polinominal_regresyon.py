import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn import preprocessing
import statsmodels.api as sm
from sklearn.metrics import r2_score

"""
polinominal regresyonda n.dereceye cıkan denklemlerdir
polinomun derecesinden bahsediyor oluyoruz
burada tek bir değişken var değişik çarpanlarla carpılmıs halidir
dogrusal değilde kırınımlı görüntüdedir.
dogrusal artmayan işlemlerde tercih edilir.
dereceye bağlıdır


"""
veriler = pd.read_csv('maaslar.csv')
print(veriler)
#data frame dilimleme , yani sutunları aldık ,dilimi aldık
x=veriler.iloc[:,1:2]
y=veriler.iloc[:,2:] #sutunları alırız
#numpy arraye cevirmiş oluyoruz
X=x.values
Y=y.values


#polinominal olarak kullanıp lineere oturturuz
poly_reg=PolynomialFeatures(degree=5) #derece arttıkca daha iyi oturuyor grafiğe
x_poly=poly_reg.fit_transform(X)

lin_reg=LinearRegression()
lin_reg.fit(x_poly,y)
plt.scatter(X,Y,color='red')
plt.plot(X,lin_reg.predict(poly_reg.fit_transform(X)),color='blue')
plt.show()
print(r2_score(Y,lin_reg.predict(X)))
