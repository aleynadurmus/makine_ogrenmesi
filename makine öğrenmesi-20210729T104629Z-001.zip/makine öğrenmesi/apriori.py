import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
import scipy.cluster.hierarchy as sch

"""
birliktelik kural çıkarımı

herhangi bir eylem tekrar ediyorsa bunu alanlar bunu da aldı mantığıyla çalışır
acaba biz kime neyi satarız mantıgıdır
korelasyon bir neden değildir
önemli olan aradaki ilişkiyi bulmak
destek =varlıgı içeren eylemler/tolam eylem sayısı
confidence(güven aralıgı)=a ve b varlıgını iççeren/a varlıgını içeren
lift() =a eyleminin b eylemine etkisi nedir? 
kola alanlar cips de aldı gibi
sistemin frekanslarını sayar belirli bir değer altında kalanı yok sayar
min support=%50
veri tabanında hangi ürünlerin kaçar kez cıktıgının frekanslarını cıkartırız 
coca colada bardak verilmesi

sklearn de bunun algoritması yoktur
apriari python githubda vardır bulunabilir.
"""

veriler = pd.read_csv('sepet.csv',header=None)

t=[]
for i in range(0,7501):
    t.append([str(veriler.values[i,j]) for j in range(0,20)])


kural=apriori(t,min_support=0.01,min_confidence=0.2,min_lift=3)
print(list(kural))


from apyori import apriori
"""x=veriler.iloc[:,3:].values 
sc=StandardScaler()


kmeans=AgglomerativeClustering(n_clusters=4, affinity='euclidean',linkage='ward')
tahmin=kmeans.fit_predict(x)
print(tahmin)

"""







