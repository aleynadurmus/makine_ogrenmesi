import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
import scipy.cluster.hierarchy as sch
import random
import re
import nltk
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import GaussianNB


cv=CountVectorizer(max_features=1000) #kelimeleri limitleyerek en cok kullanlnları alır
#kelime vektoru olusturuyoruz
"""
yazılmıs olan bir dili algılamka-ya da başka diller üretmek 
yaklasımlar:dilbilim yaklaşımı,istatiksel yaklasım,hibrit yaklaşım
stop words:anlamsız kelimeleri cümleden atmak
"""

   

durma=nltk.download('stopwords')
ps=PorterStemmer()

yorumlar = pd.read_csv('Restaurant_Reviews.csv', error_bad_lines=False)
#noktalama işaretlerinden kurtuluyoruz 
derlem=[]
for i in range(1000):
        yorum=re.sub('[^a-zA-Z]',' ',yorumlar['Review'][i])  #sub =değiştir demek
        yorum=yorum.lower()
        yorum=yorum.split() #liste yapar
        yorum =[ps.stem(kelime) for kelime in yorum if not kelime in set(stopwords.words('english'))]
        yorum=' '.join(yorum) #join birleştirme işlemidir
        #buyuk harfleri kücük harfe dönüştürütyorum
        #stop word ile gereksiz cümleleri atmak
        derlem.append(yorum) #kelimeleri listeler yapıyor tek tek filtreliyot
#vektorlerin yardımı bize kelimeleri sayılara dönüştürmeye yarıyor
x=cv.fit_transform(derlem).toarray()#bagımlı değişkeni eğitip diziye cevirip 
y=yorumlar.iloc[:,1].values#bagımsız


x_train, x_test,y_train,y_test = train_test_split(x,y,test_size=0.33, random_state=0)
gnb=GaussianNB()
gnb.fit(x_train,y_train)
y_pred=gnb.predict(x_test)
cm=confusion_matrix(y_test,y_pred)
print(cm)
"""

kelime vektorleri
(öznitelik cıkarma)
kelime sayılarını sayıp 
"""





















