import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

#veriyi yükleme
veriler=pd.read_csv('satislar.csv')
print(veriler)


aylar=veriler[['Aylar']]
print(aylar)
#bagımlı dğişken

satislar=veriler[['Satislar']]
print(satislar)
#bagızsız

#lineer regresyon : y=ax+b

#a egim oluyor b ise katsayı, kayma oluyor
#amac noktalara uygun doğruyu cizmek
#gercek değerle daha sonra hatayı minimize ederiz.
#lineer regresyonda dogrusallık mevcuttur
#zamana baglı satısı veriler uzerinden gosteriyo
#aylR BAGIMSIZ O YUZDEN 1. OLACAK O YUZDEN ONU YAZARIZ
x_train,x_test,y_train,y_test=train_test_split(aylar,satislar,test_size=0.3,random_state=0)


sc=StandardScaler() #standart olarak kullandık normal olarak da kullabiliriz.
#standartlaştırmanın amacı aynı dunyaya getirmek
X_train=sc.fit_transform(x_train)
X_test=sc.fit_transform(x_test)
Y_train=sc.fit_transform(y_train)
Y_test=sc.fit_transform(y_test)


#modeli lineer modele oturtuyoruz
lr=LinearRegression()
lr.fit(X_train, Y_train) #sayılar arasında bir baglantı olusturup bir grafiğe oturtuyor.



print(lr.predict([[11]]))
print(r2_score(Y_train,lr.predict(X_train)))
