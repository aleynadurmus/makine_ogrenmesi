import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

"""
kernel trick
marjinler içerisinde nokta varsa , nokta kabul etmiyorsa hard- marjin
eğer içerisinden hata olarak noktaları kabul ediyorsa buna soft- marijn deniyor
doğrusal olmayan durumlarda çekirdek (kernel) hileleri kullanılır,boyut arttırılmaya gidilir
iç içe sınıflarda genellikle kullanılır,3.bir boyut elde etmeye calısılır.
svm kullanarak 3.boyuta geçip burada dairesel içiçe girmiş sınıfları ayırırız
non linear sınıflar yari iç içe daire gibi gözüken şeye denir.
kernel fonk kullanılarak dogu sigma değerine sahip olanı dağıtarak elde etmek
kesebileceğimiz bir nokta elde ederiz.
dogrusal olmayan durumlarda tercih edilir.


çoklu kernel kullanımı
cok daha değişik dalgalı verileri olduğu durumda şekli değişik durumlarda birde fazla kernel kullanılır
birden fazla kernel noktası belirleyip birden fazla noktadan cekip elde ederiz 
gamma ve C değişimleri ile sonucların arasında farklılıklar olusur

"""
veriler = pd.read_csv('veriler.csv')


x=veriler.iloc[:,1:4].values
y=veriler.iloc[:,4:].values



x_train, x_test,y_train,y_test = train_test_split(x,y,test_size=0.33, random_state=0)


support=SVC(kernel='rbf') #bunu tercih ettik
support.fit(x_train,y_train) #rbf ayrım bulmaya calısacak

y_pred=support.predict(x_test)
cm=confusion_matrix(y_test,y_pred)
print(y_pred)
print(cm)