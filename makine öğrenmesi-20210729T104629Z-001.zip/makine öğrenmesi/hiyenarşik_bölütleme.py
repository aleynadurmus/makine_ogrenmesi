import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
import scipy.cluster.hierarchy as sch
"""
aggolomerative ve divisive

aggolomerative:her veri tek bir küme ile başlar en yakın ikişr komşuyu alıp ikiserli küme olusturur
en yakın 2 kümeyi alıp yeni bir bölüt olusturulr
bir önceki adım tek bir küme olana kadar devam eder
n tane elelamna varsa n tane küme var sonra birleşerek küme sayısı yarıya düşüyor spnra tekrar yakınsalar tekrar birleşiyorlar
en son bütün uzay tek bir classa dönüşür

divisive: bütün uzay tek bir küme olarak başlar
sonra 2ye bölünerek 2 küme olusuyor sonra yine kümlere bölünüp küme sayısı artar
bu algoritmalarda mesafe ölçüm farklıdır.
aralardındaki mesafe ölçümü öklit,en yakın en uzak ortalama gibi mesafeelrdir.
ağırlık mesafesi hesaplanır gibi 


dendogram:
birbirlerine olan mesafeye bakılarak kutu gibi iç içe dikdörtgenler oluyor birbirlerine olan akrabalıklara bakılır.
distance ölçülür simetrik oluyor gibi edlidean ise
bir class ile diğer class arasındaki mesafeyi bilmiş oluyoruz.
farklı mesafe stratejileri:min,max,group average,ward's method (mesafelerin karelerinin toplamı)(wcss1+wcss2+wcss12)

"""


veriler = pd.read_csv('musteriler.csv')
x=veriler.iloc[:,3:].values 
sc=StandardScaler()


kmeans=AgglomerativeClustering(n_clusters=4, affinity='euclidean',linkage='ward')
tahmin=kmeans.fit_predict(x)
print(tahmin)
plt.scatter(x[tahmin==0,0],x[tahmin==0,1],c='red')
plt.scatter(x[tahmin==1,0],x[tahmin==1,1],c='blue')
plt.scatter(x[tahmin==2,0],x[tahmin==2,1],c='green')
plt.scatter(x[tahmin==3,0],x[tahmin==3,1],c='green')

"""
#bir diğer kütühanenin dendrogram ile gösteriyor
dendrogram=sch.dendrogram(sch.linkage(x,method='ward'))
plt.show()

"""
