import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB

"""

koşullu olasılık demek de oluyor
p(A|B)=p(a n b)/p(b)
a nın gerçekleşmesinden sonra b nin gerçekleştirmeai demek 
yer değiştirme mümkün.b nin gerçekleşmesinden sonra anin gerçekleşmesi

olasılıkları çarpıp fazla cıkan olasılık değerini sonuca eşitliyoruz
bütün dağılıma bakıp olasılıksal olarak sonuca ulasılıyor
olayı olasılıga indirgeyip basitlestiriyor
sonradan ögrenmedir,lazy learnning
yeni veri gelene kadar sınıflandırma yapmaz
ögrendiğ olasılıgı aklına tutar
tüm olasılıgı hesaplayıp bagımlı ve bagımsız arasında baglantıyı kullanır


3 yöntem var gaussian bernoulli multinomial
3ü de farklı dagılım üstünden dağılır, dagılım isimlerine göre alır
veri sınıfı sürekli değerse gaussian
nominal veri sınıfı yani birbirinden farklı değerlere numaralandıram yapıyorsak multinomial
bernolli ise;ikili dagılımdır 1-0 gibi 2 cevabı var

"""

veriler = pd.read_csv('veriler.csv')


x=veriler.iloc[:,1:4].values
y=veriler.iloc[:,4:].values



x_train, x_test,y_train,y_test = train_test_split(x,y,test_size=0.33, random_state=0)


gauss=GaussianNB()
gauss.fit(x_train,y_train) 

y_pred=gauss.predict(x_test)
cm=confusion_matrix(y_test,y_pred)
print(y_pred)
print(cm)
























