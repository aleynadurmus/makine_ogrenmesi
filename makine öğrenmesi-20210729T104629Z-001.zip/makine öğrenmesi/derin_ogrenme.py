
#1.kutuphaneler
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn import preprocessing
from sklearn.metrics import confusion_matrix
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import keras
from keras.models import Sequential
from keras.layers import Dense

#2.veri onisleme
#2.1.veri yukleme
veriler = pd.read_csv('Churn_Modelling.csv')
#pd.read_csv("veriler.csv")
#test
print(veriler)

#veri on isleme

X= veriler.iloc[:,3:13].values #baştaki kolonları almayız cünkü bizim bi işimize yaramıyor
Y = veriler.iloc[:,13].values 



#encoder: Kategorik -> Numeric


le = preprocessing.LabelEncoder()
X[:,1] = le.fit_transform(X[:,1]) #yazı seklinde olanları 1-0lara ceviririz

le2 = preprocessing.LabelEncoder()
X[:,2] = le2.fit_transform(X[:,2])



ohe = ColumnTransformer([("ohe", OneHotEncoder(dtype=float),[1])],
                        remainder="passthrough"
                        )  #her kolonun aynı olmaması için ayrı ayrı olması için yaparız
X = ohe.fit_transform(X)
X = X[:,1:]




#verilerin egitim ve test icin bolunmesi
from sklearn.model_selection import train_test_split

x_train, x_test,y_train,y_test = train_test_split(X,Y,test_size=0.33, random_state=0)

#verilerin olceklenmesi
from sklearn.preprocessing import StandardScaler

sc=StandardScaler() #verileri 0-1 arasında tutmaya calısıyoruz.

X_train = sc.fit_transform(x_train)
X_test = sc.fit_transform(x_test)


#3 Yapay Sinir ağı


model = Sequential()

model.add(Dense(6, init = 'uniform', activation = 'relu' , input_dim = 11)) #uniform dagılım oldugunu gösteriyoruz

model.add(Dense(6, init = 'uniform', activation = 'relu'))#6 nöron oluyor filtre
#relu genellikle kullanılır 
model.add(Dense(1, init = 'uniform', activation = 'sigmoid'))
#sigmoid lojistik olarak kullnaılır genedle son katmanda kullan
model.compile(optimizer = 'adam', loss =  'binary_crossentropy' , metrics = ['accuracy'] )
#optimizer loss=entropi kayıp demek
model.fit(X_train, y_train, epochs=50)

y_pred = model.predict(X_test)

y_pred = (y_pred > 0.5)

cm = confusion_matrix(y_test,y_pred)

print(cm)














