import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import r2_score


"""
sınıflandırmada kullanılır ama tahminde de kullanılır
cok super bi algoritma değildir
2 boyutlu uzayda önce 2 ye bölüyor entropiye göre bölüyor
verilerin dağılımına göre ortada bölüyor
sonra tekrar bölüm yapıp diğer dallanmaları olusturuyoruz
kökten yapraklara dogru gidilir
3.boyuttaki bilgiyi 2.boyuta yerleştiririz.
dallanmaya yerleştirdikten sonra öğrenme kısmı tamamlanmıs oluyor
zaten sadece görselleştirmek için de kullanılır
ölçeklemeye ihtiyaç yoktur
"""

veriler = pd.read_csv('maaslar.csv')
print(veriler)
#data frame dilimleme , yani sutunları aldık ,dilimi aldık
x=veriler.iloc[:,1:2]
y=veriler.iloc[:,2:] #sutunları alırız
#numpy arraye cevirmiş oluyoruz
X=x.values
Y=y.values

#bütün değerleri bölerek öğrenir
r_dt=DecisionTreeRegressor(random_state=0)
r_dt.fit(X,Y)

plt.scatter(X,Y)
plt.plot(X,r_dt.predict(X))


print(r_dt.predict([[15]]))
print(r2_score(Y,r_dt.predict(X)))
