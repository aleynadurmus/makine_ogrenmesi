import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sklearn 
from sklearn.impute import SimpleImputer
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
#veriyi yükleme
veriler=pd.read_csv('satislar.csv')



aylar=veriler[['Aylar']]

#bagımlı dğişken

satislar=veriler[['Satislar']]

#bagızsız

#lineer regresyon : y=ax+b

#a egim oluyor b ise katsayı, kayma oluyor
#amac noktalara uygun doğruyu cizmek
#gercek değerle daha sonra hatayı minimize ederiz.
#lineer regresyonda dogrusallık mevcuttur
#zamana baglı satısı veriler uzerinden gosteriyo
#aylR BAGIMSIZ O YUZDEN 1. OLACAK O YUZDEN ONU YAZARIZ
#test train olarak ayırırız
x_train,x_test,y_train,y_test=train_test_split(aylar,satislar,test_size=0.3,random_state=0)
#xtrain ve y train yerlerini değiştirirsek bizim için gercek ve tahmini değerlerin yeri değişir



#bizim dosyalarımızda random olarak aylar atanmış bu yuzden sacma grefik cizmesin diye sort_index ile sıralarız
x_train=x_train.sort_index()
y_train=y_train.sort_index()


 #modeli lineer modele oturtuyoruz
lr=LinearRegression()
lr.fit(x_train, y_train) #sayılar arasında bir baglantı olusturup bir grafiğe oturtuyor.
tahmin=lr.predict(x_test)




plt.plot(x_train,y_train)
plt.plot(x_test,lr.predict(x_test))
plt.xlabel("aylar")
plt.ylabel("satıs")
#X_TRAİN VE X_TEST BİZİM GERÇEK VERİLERİMİZ Y_TRAİN VE Y_TEST BİZİM TAHMİNLERİMİZ OLUYOR





